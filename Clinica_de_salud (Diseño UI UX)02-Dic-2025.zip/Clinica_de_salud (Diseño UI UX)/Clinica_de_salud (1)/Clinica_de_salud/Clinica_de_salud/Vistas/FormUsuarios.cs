﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clinica_de_salud
{
    public partial class FormUsuarios : Form
    {
        public FormUsuarios()
        {
            InitializeComponent();
            LimpiarCampos();
            cmbSeso.Items.Add("masculino");
            cmbSeso.Items.Add("femenino");
            cmbRol.Items.Add("medico");
            cmbRol.Items.Add("secretaria");
            cmbRol.Items.Add("paciente");
        }

        private void LimpiarCampos()
        {
            txtNombre.Text = string.Empty;
            txtApellido.Text = string.Empty;
            txtRut.Text = string.Empty;
            txtTelefono.Text = string.Empty;
            txtCorreo.Text = string.Empty;
            txtDireccion.Text = string.Empty;
            txttipoSangre.Text = string.Empty;
            txtPrevision.Text = string.Empty;
            cmbSeso.Text = string.Empty;
            cmbSeso.Text = string.Empty;
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text.Trim();
            string apellido = txtApellido.Text.Trim();
            string rut = txtRut.Text.Trim();
            string contraseña = txtContraseña.Text.Trim();
            string sexo = cmbSeso.Text.Trim();
            string direccion = txtDireccion.Text.Trim();
            string telefono = txtTelefono.Text.Trim();
            string email = txtCorreo.Text.Trim();
            string prevision = txtPrevision.Text.Trim();
            string rol = cmbRol.Text.Trim();
            string sangre = txttipoSangre.Text.Trim();

            if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(contraseña) || string.IsNullOrEmpty(sexo) || string.IsNullOrEmpty(direccion))
            {
                MessageBox.Show("Todos los campos son obligatorios", "Validación", MessageBoxButtons.OK);
                return;
            }

            string contraseña_pura = BCrypt.Net.BCrypt.HashPassword(contraseña);

            try
            {
                using (var conn = Conexion.ObtenerConexion())
                {
                    conn.Open();
                    string queryUsuario = "INSERT INTO usuarios (nombre,apellido,rut,telefono,email,direccion,tipo_sangre,prevision,sexo,rol,contraseña) VALUES (@nombre,@apellido,@rut,@telefono,@email,@direccion,@tipo_sangre,@prevision,@sexo,@rol,@password)";

                    MySqlCommand cmdUsuarios = new MySqlCommand(queryUsuario, conn);
                    cmdUsuarios.Parameters.AddWithValue("@nombre", nombre);
                    cmdUsuarios.Parameters.AddWithValue("@rut", rut);
                    cmdUsuarios.Parameters.AddWithValue("@rol", rol);
                    cmdUsuarios.Parameters.AddWithValue("@sexo", sexo);
                    cmdUsuarios.Parameters.AddWithValue("@direccion", direccion);
                    cmdUsuarios.Parameters.AddWithValue("@telefono", telefono);
                    cmdUsuarios.Parameters.AddWithValue("@email", email);
                    cmdUsuarios.Parameters.AddWithValue("@prevision", prevision);
                    cmdUsuarios.Parameters.AddWithValue("@tipo_sangre", sangre);
                    cmdUsuarios.Parameters.AddWithValue("@apellido", apellido);
                    cmdUsuarios.Parameters.AddWithValue("@password", contraseña);

                    cmdUsuarios.ExecuteNonQuery();

                    cmdUsuarios.ExecuteNonQuery();
                    MessageBox.Show("Registro completo", "Éxito", MessageBoxButtons.OK);
                    LimpiarCampos();
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ocurrio un error 😣😣😣: {ex.Message}", "Error", MessageBoxButtons.OK);
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnEditar_Click(object sender, EventArgs e)
        {

        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            
        }
    }
}