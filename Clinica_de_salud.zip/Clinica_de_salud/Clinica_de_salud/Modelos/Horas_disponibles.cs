﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clinica_de_salud.Modelos
{
    public class Horas_disponibles
    {
        public int id { get; set; }
        public int medico_id { get; set; }
        public DateTime fecha { get; set; }
        public TimeSpan hora { get; set; }
        public string estado { get; set; }
        public DateTime fecha_creacion { get; set; }

    }
}
