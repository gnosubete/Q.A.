﻿namespace Clinica_de_salud
{
    partial class FormHistorialSecretaria
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            dgvHistorialSecretaria = new DataGridView();
            cmbNombrePaciente = new ComboBox();
            label1 = new Label();
            BtnRefrescar = new Button();
            btnEditar = new Button();
            btnEliminar = new Button();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvHistorialSecretaria).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnEliminar);
            groupBox1.Controls.Add(btnEditar);
            groupBox1.Controls.Add(BtnRefrescar);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(cmbNombrePaciente);
            groupBox1.Controls.Add(dgvHistorialSecretaria);
            groupBox1.Location = new Point(14, 10);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(774, 438);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Ficha Paciente:";
            // 
            // dgvHistorialSecretaria
            // 
            dgvHistorialSecretaria.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvHistorialSecretaria.Location = new Point(233, 14);
            dgvHistorialSecretaria.Name = "dgvHistorialSecretaria";
            dgvHistorialSecretaria.Size = new Size(535, 414);
            dgvHistorialSecretaria.TabIndex = 0;
            // 
            // cmbNombrePaciente
            // 
            cmbNombrePaciente.FormattingEnabled = true;
            cmbNombrePaciente.Location = new Point(8, 61);
            cmbNombrePaciente.Name = "cmbNombrePaciente";
            cmbNombrePaciente.Size = new Size(219, 23);
            cmbNombrePaciente.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(8, 29);
            label1.Name = "label1";
            label1.Size = new Size(116, 17);
            label1.TabIndex = 2;
            label1.Text = "Nombre Paciente:";
            label1.Click += label1_Click;
            // 
            // BtnRefrescar
            // 
            BtnRefrescar.Font = new Font("Malgun Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BtnRefrescar.Location = new Point(33, 118);
            BtnRefrescar.Name = "BtnRefrescar";
            BtnRefrescar.Size = new Size(107, 38);
            BtnRefrescar.TabIndex = 3;
            BtnRefrescar.Text = "Refrescar";
            BtnRefrescar.UseVisualStyleBackColor = true;
            // 
            // btnEditar
            // 
            btnEditar.Font = new Font("Malgun Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEditar.Location = new Point(33, 174);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(103, 42);
            btnEditar.TabIndex = 4;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = true;
            // 
            // btnEliminar
            // 
            btnEliminar.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEliminar.Location = new Point(33, 232);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(103, 40);
            btnEliminar.TabIndex = 5;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = true;
            // 
            // FormHistorialSecretaria
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox1);
            Name = "FormHistorialSecretaria";
            Text = "Historial Paciente";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvHistorialSecretaria).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label label1;
        private ComboBox cmbNombrePaciente;
        private DataGridView dgvHistorialSecretaria;
        private Button BtnRefrescar;
        private Button btnEliminar;
        private Button btnEditar;
    }
}