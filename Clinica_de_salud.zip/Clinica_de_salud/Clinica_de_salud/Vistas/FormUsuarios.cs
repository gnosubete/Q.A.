﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clinica_de_salud
{
    public partial class FormUsuarios : Form
    {
        public FormUsuarios()
        {
            InitializeComponent();
            LimpiarCampos();
        }

        private void LimpiarCampos()
        {
            txtNombre.Text = string.Empty;
            txtApellido.Text = string.Empty;
            txtRut.Text = string.Empty;
            txtTelefono.Text = string.Empty;
            txtCorreo.Text = string.Empty;
            txtDireccion.Text = string.Empty;
            txttipoSangre.Text = string.Empty;
            txtprevision.Text = string.Empty;
            cmbSexo.Text = string.Empty;
            cmbSexo.Text = string.Empty;
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            /* string nombre = txtNombre.Text.Trim();
            string apellido = txtApellido.Text.Trim();
            string rut = txtRut.Text.Trim();
            string telefono = txtTelefono.Text.Trim();
            string correo = txtCorreo.Text.Trim();
            string direccion = txtDireccion.Text.Trim();
            string sangre = txttipoSangre.Text.Trim();
            string prevision = txtprevision.Text.Trim();
            string sexo = cmbSexo.Text.Trim();
            string rol = cmbRol.Text.Trim();

            if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(apellido) || string.IsNullOrEmpty(rut) || string.IsNullOrEmpty(telefono) || string.IsNullOrEmpty(correo) || string.IsNullOrEmpty(direccion) || string.IsNullOrEmpty(sangre) || string.IsNullOrEmpty(prevision) || string.IsNullOrEmpty(sexo) || string.IsNullOrEmpty(rol))
            {
                MessageBox.Show("Todos los campos son obligatorios", "Validación", MessageBoxButtons.OK);
                return;
            }

            try
            {
                using (var conn = Conexion.ObtenerConexion())
                {
                    conn.Open();

                    string queryUsuarios = "INSERT INTO usuarios (rut, nombre, email, password, rol) VALUES (@rutUsuario, @nombreUsuario, @emailUsuario, @password, @rol)";

                    MySqlCommand cmdUsuarios = new MySqlCommand(queryUsuarios, conn);
                    cmdUsuarios.Parameters.AddWithValue("@rutUsuario", rut);
                    cmdUsuarios.Parameters.AddWithValue("@nombreUsuario", nombre);
                    cmdUsuarios.Parameters.AddWithValue("@emailUsuario", email);
                    cmdUsuarios.Parameters.AddWithValue("@password", contraseñaAdo);
                    cmdUsuarios.Parameters.AddWithValue("@rol", rol_usuario);

                    cmdUsuarios.ExecuteNonQuery();
                    MessageBox.Show("Registro completo", "Éxito", MessageBoxButtons.OK);
                    LimpiarCampos();
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ocurrio un error ado: {ex.Message}", "Error", MessageBoxButtons.OK);
            }*/
        }
    }
}
        