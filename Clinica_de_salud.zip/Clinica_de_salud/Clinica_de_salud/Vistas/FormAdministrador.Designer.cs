﻿namespace Clinica_de_salud
{
    partial class FormAdministrador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            groupBox1 = new GroupBox();
            contextMenuStrip1 = new ContextMenuStrip(components);
            usuariosToolStripMenuItem = new ToolStripMenuItem();
            pacientesToolStripMenuItem = new ToolStripMenuItem();
            secretariaToolStripMenuItem = new ToolStripMenuItem();
            medicosToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1 = new MenuStrip();
            usuariosToolStripMenuItem1 = new ToolStripMenuItem();
            pacientesToolStripMenuItem1 = new ToolStripMenuItem();
            secretariasToolStripMenuItem = new ToolStripMenuItem();
            medicosToolStripMenuItem1 = new ToolStripMenuItem();
            flujoDeCajaToolStripMenuItem = new ToolStripMenuItem();
            totalRecaudadoToolStripMenuItem = new ToolStripMenuItem();
            inicioToolStripMenuItem = new ToolStripMenuItem();
            cerrarSesionToolStripMenuItem = new ToolStripMenuItem();
            salirToolStripMenuItem = new ToolStripMenuItem();
            groupBox1.SuspendLayout();
            contextMenuStrip1.SuspendLayout();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(menuStrip1);
            groupBox1.Location = new Point(15, 7);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(783, 252);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Gestion:";
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.Items.AddRange(new ToolStripItem[] { usuariosToolStripMenuItem, pacientesToolStripMenuItem, secretariaToolStripMenuItem, medicosToolStripMenuItem });
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(126, 92);
            // 
            // usuariosToolStripMenuItem
            // 
            usuariosToolStripMenuItem.Name = "usuariosToolStripMenuItem";
            usuariosToolStripMenuItem.Size = new Size(125, 22);
            usuariosToolStripMenuItem.Text = "Usuarios";
            // 
            // pacientesToolStripMenuItem
            // 
            pacientesToolStripMenuItem.Name = "pacientesToolStripMenuItem";
            pacientesToolStripMenuItem.Size = new Size(125, 22);
            pacientesToolStripMenuItem.Text = "Pacientes";
            // 
            // secretariaToolStripMenuItem
            // 
            secretariaToolStripMenuItem.Name = "secretariaToolStripMenuItem";
            secretariaToolStripMenuItem.Size = new Size(125, 22);
            secretariaToolStripMenuItem.Text = "Secretaria";
            // 
            // medicosToolStripMenuItem
            // 
            medicosToolStripMenuItem.Name = "medicosToolStripMenuItem";
            medicosToolStripMenuItem.Size = new Size(125, 22);
            medicosToolStripMenuItem.Text = "Medicos";
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { inicioToolStripMenuItem, usuariosToolStripMenuItem1, flujoDeCajaToolStripMenuItem });
            menuStrip1.Location = new Point(3, 19);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(777, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // usuariosToolStripMenuItem1
            // 
            usuariosToolStripMenuItem1.DropDownItems.AddRange(new ToolStripItem[] { pacientesToolStripMenuItem1, secretariasToolStripMenuItem, medicosToolStripMenuItem1 });
            usuariosToolStripMenuItem1.Name = "usuariosToolStripMenuItem1";
            usuariosToolStripMenuItem1.Size = new Size(64, 20);
            usuariosToolStripMenuItem1.Text = "Usuarios";
            // 
            // pacientesToolStripMenuItem1
            // 
            pacientesToolStripMenuItem1.Name = "pacientesToolStripMenuItem1";
            pacientesToolStripMenuItem1.Size = new Size(180, 22);
            pacientesToolStripMenuItem1.Text = "Pacientes";
            // 
            // secretariasToolStripMenuItem
            // 
            secretariasToolStripMenuItem.Name = "secretariasToolStripMenuItem";
            secretariasToolStripMenuItem.Size = new Size(180, 22);
            secretariasToolStripMenuItem.Text = "Secretarias";
            // 
            // medicosToolStripMenuItem1
            // 
            medicosToolStripMenuItem1.Name = "medicosToolStripMenuItem1";
            medicosToolStripMenuItem1.Size = new Size(180, 22);
            medicosToolStripMenuItem1.Text = "Medicos";
            // 
            // flujoDeCajaToolStripMenuItem
            // 
            flujoDeCajaToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { totalRecaudadoToolStripMenuItem });
            flujoDeCajaToolStripMenuItem.Name = "flujoDeCajaToolStripMenuItem";
            flujoDeCajaToolStripMenuItem.Size = new Size(87, 20);
            flujoDeCajaToolStripMenuItem.Text = "Flujo de Caja";
            // 
            // totalRecaudadoToolStripMenuItem
            // 
            totalRecaudadoToolStripMenuItem.Name = "totalRecaudadoToolStripMenuItem";
            totalRecaudadoToolStripMenuItem.Size = new Size(180, 22);
            totalRecaudadoToolStripMenuItem.Text = "Total recaudado";
            // 
            // inicioToolStripMenuItem
            // 
            inicioToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { cerrarSesionToolStripMenuItem, salirToolStripMenuItem });
            inicioToolStripMenuItem.Name = "inicioToolStripMenuItem";
            inicioToolStripMenuItem.Size = new Size(48, 20);
            inicioToolStripMenuItem.Text = "Inicio";
            // 
            // cerrarSesionToolStripMenuItem
            // 
            cerrarSesionToolStripMenuItem.Name = "cerrarSesionToolStripMenuItem";
            cerrarSesionToolStripMenuItem.Size = new Size(180, 22);
            cerrarSesionToolStripMenuItem.Text = "Cerrar Sesion";
            // 
            // salirToolStripMenuItem
            // 
            salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            salirToolStripMenuItem.Size = new Size(180, 22);
            salirToolStripMenuItem.Text = "Salir";
            // 
            // FormAdministrador
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 271);
            Controls.Add(groupBox1);
            MainMenuStrip = menuStrip1;
            Name = "FormAdministrador";
            Text = "Adminsitrador";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            contextMenuStrip1.ResumeLayout(false);
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem usuariosToolStripMenuItem1;
        private ToolStripMenuItem pacientesToolStripMenuItem1;
        private ToolStripMenuItem secretariasToolStripMenuItem;
        private ToolStripMenuItem medicosToolStripMenuItem1;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem usuariosToolStripMenuItem;
        private ToolStripMenuItem pacientesToolStripMenuItem;
        private ToolStripMenuItem secretariaToolStripMenuItem;
        private ToolStripMenuItem medicosToolStripMenuItem;
        private ToolStripMenuItem inicioToolStripMenuItem;
        private ToolStripMenuItem cerrarSesionToolStripMenuItem;
        private ToolStripMenuItem salirToolStripMenuItem;
        private ToolStripMenuItem flujoDeCajaToolStripMenuItem;
        private ToolStripMenuItem totalRecaudadoToolStripMenuItem;
    }
}