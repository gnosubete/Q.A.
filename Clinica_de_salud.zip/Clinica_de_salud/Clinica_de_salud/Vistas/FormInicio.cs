﻿using Clinica_de_salud.Vistas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clinica_de_salud
{
    public partial class FormInicio : Form
    {
        public FormInicio()
        {
            InitializeComponent();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnregistro_Click(object sender, EventArgs e)
        {
            FormRegistrosPacientes c = new FormRegistrosPacientes();
            c.ShowDialog();
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            FormLogin c = new FormLogin();
            c.ShowDialog();
        }
    }
}
