﻿namespace Clinica_de_salud
{
    partial class FormCaja
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            txtTotal = new TextBox();
            cmbNombrePaciente = new ComboBox();
            label1 = new Label();
            label2 = new Label();
            btnPagar = new Button();
            dgvRegistro = new DataGridView();
            btnRefrescar = new Button();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvRegistro).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnRefrescar);
            groupBox1.Controls.Add(dgvRegistro);
            groupBox1.Controls.Add(btnPagar);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(cmbNombrePaciente);
            groupBox1.Controls.Add(txtTotal);
            groupBox1.Location = new Point(1, 3);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(798, 448);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            // 
            // txtTotal
            // 
            txtTotal.Location = new Point(130, 91);
            txtTotal.Name = "txtTotal";
            txtTotal.Size = new Size(244, 23);
            txtTotal.TabIndex = 1;
            // 
            // cmbNombrePaciente
            // 
            cmbNombrePaciente.FormattingEnabled = true;
            cmbNombrePaciente.Location = new Point(130, 50);
            cmbNombrePaciente.Name = "cmbNombrePaciente";
            cmbNombrePaciente.Size = new Size(244, 23);
            cmbNombrePaciente.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(22, 53);
            label1.Name = "label1";
            label1.Size = new Size(102, 15);
            label1.TabIndex = 3;
            label1.Text = "Nombre Paciente:";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(22, 99);
            label2.Name = "label2";
            label2.Size = new Size(78, 15);
            label2.TabIndex = 4;
            label2.Text = "Total a pagar:";
            // 
            // btnPagar
            // 
            btnPagar.Location = new Point(48, 237);
            btnPagar.Name = "btnPagar";
            btnPagar.Size = new Size(100, 50);
            btnPagar.TabIndex = 5;
            btnPagar.Text = "Pagar";
            btnPagar.UseVisualStyleBackColor = true;
            // 
            // dgvRegistro
            // 
            dgvRegistro.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvRegistro.Location = new Point(408, 9);
            dgvRegistro.Name = "dgvRegistro";
            dgvRegistro.Size = new Size(384, 433);
            dgvRegistro.TabIndex = 6;
            // 
            // btnRefrescar
            // 
            btnRefrescar.Location = new Point(49, 148);
            btnRefrescar.Name = "btnRefrescar";
            btnRefrescar.Size = new Size(99, 50);
            btnRefrescar.TabIndex = 7;
            btnRefrescar.Text = "Refrescar";
            btnRefrescar.UseVisualStyleBackColor = true;
            // 
            // FormCaja
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox1);
            Name = "FormCaja";
            Text = "Registro Financiero";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvRegistro).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label label1;
        private ComboBox cmbNombrePaciente;
        private TextBox txtTotal;
        private Label label2;
        private Button btnPagar;
        private Button btnRefrescar;
        private DataGridView dgvRegistro;
    }
}