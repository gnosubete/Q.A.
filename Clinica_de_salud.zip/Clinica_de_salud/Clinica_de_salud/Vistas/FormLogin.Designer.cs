﻿namespace Clinica_de_salud
{
    partial class FormLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            button1 = new Button();
            txtcontraseña = new TextBox();
            txtrut = new TextBox();
            label2 = new Label();
            label1 = new Label();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(txtcontraseña);
            groupBox1.Controls.Add(txtrut);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(17, 11);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(341, 455);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Acceder";
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI Variable Display Semib", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(106, 281);
            button1.Name = "button1";
            button1.Size = new Size(105, 58);
            button1.TabIndex = 4;
            button1.Text = "Acceder";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // txtcontraseña
            // 
            txtcontraseña.Location = new Point(62, 210);
            txtcontraseña.Name = "txtcontraseña";
            txtcontraseña.Size = new Size(197, 23);
            txtcontraseña.TabIndex = 3;
            // 
            // txtrut
            // 
            txtrut.Location = new Point(62, 124);
            txtrut.Name = "txtrut";
            txtrut.Size = new Size(197, 23);
            txtrut.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Variable Display", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(91, 162);
            label2.Name = "label2";
            label2.Size = new Size(120, 26);
            label2.TabIndex = 1;
            label2.Text = "Contraseña:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Variable Display", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(127, 79);
            label1.Name = "label1";
            label1.Size = new Size(54, 26);
            label1.TabIndex = 0;
            label1.Text = "RUT:";
            // 
            // FormLogin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(370, 478);
            Controls.Add(groupBox1);
            Name = "FormLogin";
            Text = "Iniciar Sesion";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label label2;
        private Label label1;
        private Button button1;
        private TextBox txtcontraseña;
        private TextBox txtrut;
    }
}