﻿namespace Clinica_de_salud
{
    partial class FormInicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            btnlogin = new Button();
            btnregistro = new Button();
            menuStrip1 = new MenuStrip();
            inicioToolStripMenuItem = new ToolStripMenuItem();
            cerrarSesionToolStripMenuItem = new ToolStripMenuItem();
            salirToolStripMenuItem = new ToolStripMenuItem();
            sobreNosotrosToolStripMenuItem = new ToolStripMenuItem();
            nuestraHistoriaToolStripMenuItem = new ToolStripMenuItem();
            medicosYEspecialidadesToolStripMenuItem = new ToolStripMenuItem();
            medicinaGeneralToolStripMenuItem = new ToolStripMenuItem();
            especialidadesToolStripMenuItem = new ToolStripMenuItem();
            miHistorialToolStripMenuItem = new ToolStripMenuItem();
            archivoToolStripMenuItem = new ToolStripMenuItem();
            groupBox2 = new GroupBox();
            groupBox1.SuspendLayout();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnlogin);
            groupBox1.Controls.Add(btnregistro);
            groupBox1.Controls.Add(menuStrip1);
            groupBox1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(6, 62);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(586, 304);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Bienvenidos a Clinica Saludable!";
            // 
            // btnlogin
            // 
            btnlogin.Location = new Point(131, 143);
            btnlogin.Name = "btnlogin";
            btnlogin.Size = new Size(382, 58);
            btnlogin.TabIndex = 1;
            btnlogin.Text = "Boton de login";
            btnlogin.UseVisualStyleBackColor = true;
            btnlogin.Click += btnlogin_Click;
            // 
            // btnregistro
            // 
            btnregistro.Location = new Point(131, 79);
            btnregistro.Name = "btnregistro";
            btnregistro.Size = new Size(382, 58);
            btnregistro.TabIndex = 0;
            btnregistro.Text = "Boton de registro";
            btnregistro.UseVisualStyleBackColor = true;
            btnregistro.Click += btnregistro_Click;
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { inicioToolStripMenuItem, sobreNosotrosToolStripMenuItem, medicosYEspecialidadesToolStripMenuItem, miHistorialToolStripMenuItem });
            menuStrip1.Location = new Point(3, 25);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(580, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            menuStrip1.ItemClicked += menuStrip1_ItemClicked;
            // 
            // inicioToolStripMenuItem
            // 
            inicioToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { cerrarSesionToolStripMenuItem, salirToolStripMenuItem });
            inicioToolStripMenuItem.Name = "inicioToolStripMenuItem";
            inicioToolStripMenuItem.Size = new Size(48, 20);
            inicioToolStripMenuItem.Text = "Inicio";
            // 
            // cerrarSesionToolStripMenuItem
            // 
            cerrarSesionToolStripMenuItem.Name = "cerrarSesionToolStripMenuItem";
            cerrarSesionToolStripMenuItem.Size = new Size(143, 22);
            cerrarSesionToolStripMenuItem.Text = "Cerrar Sesion";
            // 
            // salirToolStripMenuItem
            // 
            salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            salirToolStripMenuItem.Size = new Size(143, 22);
            salirToolStripMenuItem.Text = "Salir";
            // 
            // sobreNosotrosToolStripMenuItem
            // 
            sobreNosotrosToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { nuestraHistoriaToolStripMenuItem });
            sobreNosotrosToolStripMenuItem.Name = "sobreNosotrosToolStripMenuItem";
            sobreNosotrosToolStripMenuItem.Size = new Size(99, 20);
            sobreNosotrosToolStripMenuItem.Text = "Nuestra Clinica";
            // 
            // nuestraHistoriaToolStripMenuItem
            // 
            nuestraHistoriaToolStripMenuItem.Name = "nuestraHistoriaToolStripMenuItem";
            nuestraHistoriaToolStripMenuItem.Size = new Size(157, 22);
            nuestraHistoriaToolStripMenuItem.Text = "Nuestra historia";
            // 
            // medicosYEspecialidadesToolStripMenuItem
            // 
            medicosYEspecialidadesToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { medicinaGeneralToolStripMenuItem, especialidadesToolStripMenuItem });
            medicosYEspecialidadesToolStripMenuItem.Name = "medicosYEspecialidadesToolStripMenuItem";
            medicosYEspecialidadesToolStripMenuItem.Size = new Size(152, 20);
            medicosYEspecialidadesToolStripMenuItem.Text = "Medicos y especialidades";
            // 
            // medicinaGeneralToolStripMenuItem
            // 
            medicinaGeneralToolStripMenuItem.Name = "medicinaGeneralToolStripMenuItem";
            medicinaGeneralToolStripMenuItem.Size = new Size(166, 22);
            medicinaGeneralToolStripMenuItem.Text = "Medicina General";
            // 
            // especialidadesToolStripMenuItem
            // 
            especialidadesToolStripMenuItem.Name = "especialidadesToolStripMenuItem";
            especialidadesToolStripMenuItem.Size = new Size(166, 22);
            especialidadesToolStripMenuItem.Text = "Especialidades";
            // 
            // miHistorialToolStripMenuItem
            // 
            miHistorialToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { archivoToolStripMenuItem });
            miHistorialToolStripMenuItem.Name = "miHistorialToolStripMenuItem";
            miHistorialToolStripMenuItem.Size = new Size(80, 20);
            miHistorialToolStripMenuItem.Text = "Mi Historial";
            // 
            // archivoToolStripMenuItem
            // 
            archivoToolStripMenuItem.Name = "archivoToolStripMenuItem";
            archivoToolStripMenuItem.Size = new Size(161, 22);
            archivoToolStripMenuItem.Text = "Historial Medico";
            // 
            // groupBox2
            // 
            groupBox2.Location = new Point(5, 4);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(790, 52);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            // 
            // FormInicio
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(606, 389);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            MainMenuStrip = menuStrip1;
            Name = "FormInicio";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem inicioToolStripMenuItem;
        private ToolStripMenuItem sobreNosotrosToolStripMenuItem;
        private ToolStripMenuItem medicosYEspecialidadesToolStripMenuItem;
        private ToolStripMenuItem nuestraHistoriaToolStripMenuItem;
        private ToolStripMenuItem medicinaGeneralToolStripMenuItem;
        private ToolStripMenuItem especialidadesToolStripMenuItem;
        private GroupBox groupBox2;
        private ToolStripMenuItem cerrarSesionToolStripMenuItem;
        private ToolStripMenuItem salirToolStripMenuItem;
        private ToolStripMenuItem miHistorialToolStripMenuItem;
        private ToolStripMenuItem archivoToolStripMenuItem;
        private Button btnlogin;
        private Button btnregistro;
    }
}