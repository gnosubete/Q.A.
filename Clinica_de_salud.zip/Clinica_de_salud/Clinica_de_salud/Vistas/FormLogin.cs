﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clinica_de_salud
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string rut = txtrut.Text.Trim();
            string contraseña = txtcontraseña.Text.Trim();

            if (string.IsNullOrEmpty(rut) || string.IsNullOrEmpty(contraseña))
            {
                MessageBox.Show("Por favor, ingrese RUT y contraseña.", "Aviso", MessageBoxButtons.OK);
                return;
            }

            try
            {
                using (var conn = Conexion.ObtenerConexion())
                {
                    conn.Open();
                    string query = "SELECT password FROM usuarios WHERE rut = @rut";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@rut", rut);
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string hash = reader["password"].ToString();
                            bool correcto = BCrypt.Net.BCrypt.Verify(contraseña, hash);
                            if (correcto)
                            {
                                MessageBox.Show($"Bienvenido {rut}", "Acceso Correcto", MessageBoxButtons.OK);
                                FormInicio principal = new FormInicio(); //falta configurar menu inicio para que el usuario solo vea sus datos (rut)
                                principal.Show();
                                this.Hide();
                            }
                            else
                            {
                                MessageBox.Show("Credenciales incorrectas", "Error", MessageBoxButtons.OK);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
